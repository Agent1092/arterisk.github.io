var app = angular.module('angularTable', ['angularUtils.directives.dirPagination']);

app.controller('listdata',function($scope, $http){
   // $scope.sortKey='exdate';
    $scope.search1='';
   // alert('s');
    $scope.users = []; //declare an empty array
    
    $http.get("domainpricedata.php").success(function(response){ 
        
        $scope.users = response;  //ajax request to fetch data into $scope.data
    });
    
   // alert('g');
    $scope.myFunc = function($a) {
     // alert($a);
      showdetails($a);
    };
    
    $scope.sort = function(keyname){
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };
});
