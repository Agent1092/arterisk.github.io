<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        
        
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=DM+Sans:400,500,700|Raleway:300,400,500,600,700,800,900&display=swap" rel="stylesheet"> 
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/owl.carousel.min.css">

<link rel="stylesheet" href="../css/default.css">		
<link rel="stylesheet" href="../style.css">
<link rel="stylesheet" href="../css/mystyle.css">
<link rel="stylesheet" href="../css/jPushMenu.css">



<link rel="stylesheet" href="../css/custom.css">


<script src="../js/jquery.min.js"></script>
<script src="../js/jquery.bxslider.js"></script>
<script src="../js/script.js"></script>
<script src="../js/jPushMenu.js"></script>
<script src="../js/my.js"></script>



<script src="../resources/ac9281a6fe.js"></script>


  <script src="../resources/jquery.min.js"></script>
  <!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->
        
  
  
  
  
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <!-- <link rel="stylesheet" href="resources/demos/style.css"> -->
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <script src="https://www.hosting.co.in/js/owl.carousel.min.js"></script>
  
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-26057856-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-26057856-1');
</script>


<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P8BW8DG');</script>
<!-- End Google Tag Manager -->





        <title>Domain Registration - Hosting.co.in</title>
    </head>
    <body>
        <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P8BW8DG"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<header><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 
 
  <!-- <div class="header-christmas">
       
         <div style="background-color:#ffc785" class="notify-wrapper notify-wrapper--top">
             <div class="notification notify notify--banner notification--static notification--no-shadow notification--no-border notification--hide-disable mg-none-i notification--show" data-recurrent="true" data-cookie-expiry="1608454066419">
               <div  class="container-fluid">
                  <marquee direction="left" height="10%" onmouseover=this.stop(); onmouseout=this.start(); scrollamount=8;>
                    <h2 style="text-size:10px; text-align:center">
                    Monsoon Bonanza Sale is Live Now Get Upto 60% Off |  Buy Now 
                    </h2>
                 </marquee>
                    
               </div>
                   <span class="santa"></span>
                   
               
             </div>
         </div>
      
   </div>	 -->

   <!--2022 
   <div class="heades--christmas">
   <div class="container">
      <a href="https://www.hosting.co.in/premiumemail.htm">
         <div class="christmas-contant">
<p>Premium Email Hosting
<span>Upto 30% Off</span>                                               
</p>
         </div>

      </a>
   </div>
</div> -->
   
  
  

		<div id="top-header">
			
			<div class="container">
				
				<div class="section group">
				
					<div class="span_4_of_12 col">
					
						<div class="logo">
						
                                                    <a href="../index.html"><img alt="Hosting.co.in" src="../images/logo.png"></a>
											
						</div>
					
					</div>
					<div class="span_8_of_12 col">
					
						<div class="top-right-menu">
						
							
					<a href="tel: 09610000250" class="call top"><i class="fa fa-phone" aria-hidden="true"></i> 09610000250 (24 x 7)</a>
					
					<a href="mailto:support@hosting.co.in?subject = Support&body = Message" class="mail top"><i class="fa fa-envelope-o" aria-hidden="true"></i> support@hosting.co.in</a>
					<ul class="top_social">
						<li><a target="_blank" href="https://www.facebook.com/hosting.co.in" class="social"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<!-- <li><a target="_blank" href="https://www.facebook.com/hosting.co.in" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a target="_blank" href="https://www.facebook.com/hosting.co.in" class="social"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>	 -->
					</ul>
					<a target="_blank" href="https://www.facebook.com/hosting.co.in" class="social"></a>
				<!--	<a href="#" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a> -->
                                              	<a href="clientarea.php" class="blue-btn"><i class="fa fa-user"></i>My Account</a>
                                           	
                                                     
						
					  </div>
					</div>
				
				</div>	
				
			</div>
		</div>
		
	
	</header>

	<div class="main-header">
   <nav class="navbar navbar-default">
      <div class="container">

         <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>      
         </div>
         <!-- Collect the nav links, forms, and other content for toggling -->
         <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
              <!-- <li><a href="https://www.hosting.co.in">Home</a></li> -->
               <li class="dropdown megamenu mm-three">
                  <a href="domainregister.php#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Domains</a>
                  <ul class="dropdown-menu">
                     <li>
                        <a href="domainregister.php">
                           <h4>Domain Registration</h4>
                           <p>
                              Register your company domain before anyone else does it.
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>
                     <li>
                        <a href="domaintransfer.php">
                        

                           <h4>Domain Transfer</h4>
                           <p>
                              If your current service provider's renewal price is too high, transfer your domain to us free with one year renewal charges, .com domain one year renewal is @ Rs. 900 + GST.
                           </p>
                           <span class="btn btn-primary">More</span>
                        
                     </a>
                     </li>
                     <li>
                        <a href="domainprice.php">
                        
                        <h4>Domains Price List</h4>
                           <p>
                              Checkout our domain price list.
                           </p>
                           <span class="btn btn-primary">More</span>
                     </a>
                  </li>
                  </ul>
               </li>
               <li class="dropdown megamenu mm-four">
                  <a href="domainregister.php#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Linux Hosting</a>
                  <ul class="dropdown-menu ">
                     <li>
                        <a href="../linux-offers.htm">
                            <h4>Budget Hosting with cPanel </h4> 
                                   <!-- <span class="norelway">Diwali Offer</p></h4> -->
                           <p>
                              starts at Rs. 500 + GST per year <br/>
                              Features:
                            <ul>
                                  <li>cPanel Control Panel</li>
                                  <li>Free SSL</li>
                                  <li>Business Email IDs</li>
                                  
                              </ul>
                            
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>
                   
                     <li>
                        <a href="../linux-multidomain.htm">
                           <h4>Multi Domain Budget Hosting</h4>
                           <p>
                              Looking to host multiple domains in single hosting cPanel at affordable price, these plans are best fit for you.
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>
                     <li>
                        <a href="https://www.hosting.co.in/linux-hosting.htm">
                           
                           <h4>Unlimited Linux Hosting</h4>
                           <p>
                              Get Unlimited Webspace for your website with  Unlimited E-mail IDs, Mysql Databases, Free SSL and cPanel.
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>
                     <!--  <li><a href="/linux-premium.htm">Premium Hosting</a></li> -->
                     <li>
                        <a href="../webbuilder.htm">
                           
                           <h4>Website Builder Hosting</h4>
                           <p>
                              Don't want to spend huge money in website development ? try our website builder plan and build it your self, 190+ templetes are available.
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>
                  </ul>
               </li>
               <li><a href="../linux-reseller.htm">Reseller Hosting</a></li>
              <li><a href="../wordpresshosting.htm">WordPress Hosting <sup class="new-label">NEW</sup></a>
               </li>
              
               <li class="dropdown megamenu mm-three">
                  <a href="domainregister.php#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Business Email</a>
                  <!-- <sup class="new-label2">NEW</sup> -->
                  <ul class="dropdown-menu">
                     <li>
                        <a href="../premiumemail.htm">
                          
                           <h4> Premium Email</h4>
                           <p>
                              Premium E-mail plans starting at Rs. 1000 + GST per year with 10 GB space and 25 e-mail ids.<br/>
                              POP, IMAP, SMTP support for mobile and outlook, 15 days trail available on request.
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>
                     <li>
                        <a href="../gsuite.php">
                           
                           <h4>G Suite</h4>
                           <p>
                              G-Suit Email service @ Rs. 2520 + GST per user per year.
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>
                  </ul>
               </li>
           
               <li class="dropdown megamenu mm-four">
                  <a href="domainregister.php#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Cloud VPS  <sup class="new-label">NEW</sup></a>
                  <!-- <sup class="new-label1">NEW</sup> -->
                  <ul class="dropdown-menu ">
                     <li>
                        <a href="../vps.htm">
                            <h4>Linux Cloud VPS</h4> 
                            <p>
                              Looking for a private server with cPanel, plans starts at Rs. 1000 + GST per month
                           </p>
                                   <!-- <span class="norelway">Diwali Offer</p></h4> -->
                           <p>
                            
                            <ul>
                                  <li>WHM/cPanel Solo Control Panel</li>
                                  <li>Unlimited Domain Hosting</li>
                                  <li>root Access</li>
                                  <li>Free SSL</li>
                                  <li>Dedicated IP</li>
                                  
                              </ul>
                            
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>

                     <li>
                        <a href="../windows-vps.htm">
                            <h4>Windows VPS</h4> 
                            <p>
                              Looking for a Virtual Windows server, plans starts at Rs. 750 + GST per month
                           </p>
                                   <!-- <span class="norelway">Diwali Offer</p></h4> -->
                           <p>
                            
                            <ul>
                                  
                                  <li>RDP Access</li>
                                  
                                  <li>Suitable for Forex Trading and MT4 & MT5</li>
                                  
                                  <li>Also Suitable for Tally on Cloud</li>
                                  
                                  <li>Dedicated IP</li>
                                  
                              </ul>
                            
                           </p>
                           <span class="btn btn-primary">More</span>
                        </a>
                     </li>




                   
                   
                     
                  </ul>
               </li>
               <li><a href="../freeaccount.htm">Free Trial</a></li>
            </ul>
         </div>
         <!-- /.navbar-collapse -->
      </div>
      <!-- /.container-fluid -->
   </nav>
</div>

<!-- <marquee width="100%" direction="left" height="10%" style="
    background-color: #b4dbf2;">
    <h4>Add Monsoon Bonanza Sale is Live Now Get Upto 60% Off |  Buy Now </h4>
   </marquee> -->

        <!-- <div class="page_title">

            <div class="container">

                <div class="section group">
                    <div class="span_12_of_12 col">

                        <h2>Check Domain Availability</h2>  

                    </div>


                </div>

            </div>

        </div> -->

       <div class="page_content domain-register-page">
        <div class="roundshape"></div>
        <div class="container">       
            
                               
                    <form action="https://www.hosting.co.in/customer/hostingdomain.php" method="post">
                        <input type="hidden" name="planid" value="0">
                        <input type="hidden" name="domainselect" value="new">


                        <div class="row domain-register-outer">
                           <h2>Check Domain Availability</h2>  
                            <div  id="newdomain" class="domain-register-box" >

                                <input type="text" class="input-lg" name="domain" placeholder="Enter Domain Name"/> 
                                <div class="selectand-search-2">
                                <select name="dext" class="input-dr">
                                                                                <option value=".com">.com </option>
                                                                                    <option value=".in">.in </option>
                                                                                    <option value=".co.in">.co.in </option>
                                                                                    <option value=".net">.net </option>
                                                                                    <option value=".org">.org </option>
                                                                                    <option value=".ind.in">.ind.in </option>
                                                                                    <option value=".firm.in">.firm.in </option>
                                                                                    <option value=".gen.in">.gen.in </option>
                                                                                    <option value=".org.in">.org.in </option>
                                                                                    <option value=".net.in">.net.in </option>
                                                                                    <option value=".tattoo">.tattoo </option>
                                                                                    <option value=".systems">.systems </option>
                                                                                    <option value=".space">.space </option>
                                                                                    <option value=".solutions">.solutions </option>
                                                                                    <option value=".social">.social </option>
                                                                                    <option value=".site">.site </option>
                                                                                    <option value=".shiksha">.shiksha </option>
                                                                                    <option value=".property">.property </option>
                                                                                    <option value=".party">.party </option>
                                                                                    <option value=".online">.online </option>
                                                                                    <option value=".news">.news </option>
                                                                                    <option value=".love">.love </option>
                                                                                    <option value=".jobs">.jobs </option>
                                                                                    <option value=".guru">.guru </option>
                                                                                    <option value=".desi">.desi </option>
                                                                                    <option value=".company">.company </option>
                                                                                    <option value=".co">.co </option>
                                                                                    <option value=".club">.club </option>
                                                                                    <option value=".buzz">.buzz </option>
                                                                                    <option value=".asia">.asia </option>
                                                                                    <option value=".accountants">.accountants </option>
                                                                                    <option value=".academy">.academy </option>
                                                                                    <option value=".info">.info </option>
                                                                                    <option value=".biz">.biz </option>
                                                                                    <option value=".tech">.tech </option>
                                                                                    <option value=".website">.website </option>
                                                                                    <option value=".xyz">.xyz </option>
                                                                                    <option value=".yoga">.yoga </option>
                                                                                    <option value=".in.net">.in.net </option>
                                                                                    <option value=".jewelry">.jewelry </option>
                                                                                    <option value=".tours">.tours </option>
                                                                                    <option value=".university">.university </option>
                                                                                    <option value=".holiday">.holiday </option>
                                                                                    <option value=".limited">.limited </option>
                                                                                    <option value=".school">.school </option>
                                                                        </select>
                                
                                    <input class="btn-success mybtn" type="submit" value="Continue"/> 
                                </div>
                            </div>


                            
                        </div>
                    </form>
                
            
           
            

            
        </div>

        <div class="clearfix"></div>
    </div>

<div id="footer" class="footerclass">
	<div id="Footer_widget">
	
		<div class="container">
		
			<div class="section group">
				
				<div class="span_3_of_12 col">
				
					<div class="widget_box">
					
						<h5 class="widget_title">Contact Us</h5>
						<div class="widget_desc">
							
							<p>Extensive Host Private Limited</p>
							<p><a href="mailto:support@hosting.co.in" style="color: #fff;">support@hosting.co.in</a></p>
							<p><a href="tel:09610000250" style="color: #fff;">096100 00250 (24 x 7)</a></p>
												
						</div>
					
					</div>
				
				</div>
				<div class="span_3_of_12 col">
				
					<div class="widget_box">
					
						<h5 class="widget_title">Domains</h5>
						<div class="widget_desc">
							
							<ul>
							
								<li><a href="cart.php@a=add&amp;domain=register">Domain Registration</a></li>
								<li><a href="cart.php@a=add&amp;domain=transfer">Domain Transfer</a></li>
							
							
							</ul>
							
						</div>
					
					</div>
				
				</div>
				<div class="span_3_of_12 col">
				
					<div class="widget_box">
					
						<h5 class="widget_title">Web Hosting</h5>
						<div class="widget_desc">
							<ul>
							
						
                            <li><a href="https://www.hosting.co.in/linux-hosting.htm">Linux Hosting</a></li>
                            	  
                            <li><a href="../vps.htm">VPS Hosting</a></li>
							
							</ul>
						
						</div>
					
					</div>
				
				</div>
				<div class="span_3_of_12 col">
				
					<div class="widget_box">
					
						<h5 class="widget_title">Support</h5>
						<div class="widget_desc">
						
							<ul>
							
								<li><a target="_blank" href="https://blog.hosting.co.in">Blog</a></li>
								
							
							</ul>
						
						</div>
					
					</div>
				
				</div>
			
			</div>
		
		</div>
		
	
	</div>
	<div id="footer_menu">
		<div class="container">
			<div class="section group">
				<div class="span_12_of_12 col">
					<ul>
		
					<li><a href="../default.htm">Home</a></li>
                    <li><a target="_blank" href="https://blog.hosting.co.in">Blog</a></li>
                    <li><a href="../tnc.htm">Terms & Conditions</a></li>
                    <li><a href="../privacy.htm">Privacy Policy</a></li>
                    <li><a href="../disclaimer.htm">Disclaimer</a></li>  
                    <li><a href="../refund.htm">Refund Policy</a></li>
                                                    
                    <li><a href="../contact.htm">Contact Us</a></li>
					
					</ul>
				</div>
			</div>
		</div>
	</div>
	
	<div class="footer_copyright">
	
		<div class="container">
			<div class="section group">
				<div class="span_12_of_12 col">
						
						<p><a href="../index.html">Hosting.co.in </a>&copy; All Rights Reserved</p>
				</div>
			</div>
		</div>
	
	
	</div>
	</div>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-26057856-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-26057856-1');
</script>


<!--Start of Tawk.to Script-->

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/56ff7144daec1257702b6082/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>


<!--End of Tawk.to Script-->

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '456266478534587');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=456266478534587&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->


<script src="../js/custom.js"></script>

<script type="text/javascript">

	function view_item($id, $name, $listname, $category, $position, $price){

		gtag('event', 'view_item', {
		   "items": [
		     {
		        "id": $id,
		        "name": $name,
		        "list_name": $listname,
		        "brand": "Hosting.co.in",
				"category": $category,
		        "list_position": $position,
		        "quantity": 1,
		        "price": $price
		     }
		   ]
		});
	}

</script>


<script>
    var url = 'https://wati-integration-service.clare.ai/ShopifyWidget/shopifyWidget.js?69640';
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = url;
    var options = {
  "enabled":true,
  "chatButtonSetting":{
      "backgroundColor":"#4dc247",
      "ctaText":"",
      "borderRadius":"25",
      "marginLeft":"0",
      "marginBottom":"50",
      "marginRight":"50",
      "position":"left"
  },
  "brandSetting":{
      "brandName":"Hosting.co.in",
      "brandSubTitle":"",
      "brandImg":"https://www.hosting.co.in/images/logo.png",
      "welcomeText":"Hi, there!\nHow can I help you?",
      "messageText":"Hello, I have a question about {{page_link}}",
      "backgroundColor":"#d6e8f5",
      "ctaText":"Start Chat",
      "borderRadius":"25",
      "autoShow":false,
      "phoneNumber":"911414145400"
  }
};
    s.onload = function() {
        CreateWhatsappChatWidget(options);
    };
    var x = document.getElementsByTagName('script')[0];
    x.parentNode.insertBefore(s, x);
</script>
	
    </body>
</html>
